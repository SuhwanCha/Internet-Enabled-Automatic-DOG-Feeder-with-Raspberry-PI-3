<div class="footer">
  Copyright gdb.kr 2016 all rights reserved,<br>Developed by Suhwan Cha
</div>
