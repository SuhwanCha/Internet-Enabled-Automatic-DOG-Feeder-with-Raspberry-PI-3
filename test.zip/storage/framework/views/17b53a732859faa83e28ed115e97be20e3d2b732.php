
<?php $__env->startSection('content'); ?>
<div id="section1">
  <div class="container">
    <div class="content">
      <h1>Improve your life with gdb.kr</h1>
      <p style="color:#aeaeae;font-size:21px">The SmartHome Solution for animal.</p>
    </div>
    <div class="row">
      <div class="col-md-4 phone">
        <img src="img/iphone_6.png">
      </div>
      <div class="col-md-4 phone">
        <img src="img/iphone_6.png">
      </div>
      <div class="col-md-4 phone">
        <img src="img/iphone_6.png">
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<style>
.content > h1{
  /*color:white;*/
  /*text-sa*/

}
.phone > div{
}
.content{
  text-align: center;
}
.phone{
  text-align: center;
}
.phone > img{
  margin-bottom:30px;
  width:50%;
}
</style>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>